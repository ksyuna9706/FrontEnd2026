//1 Вариант

// document.writeln("<table border='1' width='150' align='center'>");
// for (let i = 1; i < 11; i++) {
//     document.writeln("<tr align='center'>");
//     for (let j = 1; j < 11; j++) {
//         if (i % 2 && j % 2 || i % 2==0 && j % 2==0) {
//             document.writeln("<td bgcolor='red'>" + i * j + "</td>");
//         } else {
//             document.writeln("<td bgcolor='yellow'>" + i * j + "</td>");
//         }
//     }
//     document.writeln("</tr>");
// }
// document.writeln("</table>");

// 2 Вариант

document.writeln("<table border='1' width='150' align='center'>");
for (let i = 0; i < 11; i++) {
    document.writeln("<tr align='center' >");
    for (let j = 0; j < 11; j++) {
        if (i == 0) {
            document.writeln("<td bgcolor='white'>" + j + "</td>");
        } else if (j == 0) {
            document.writeln("<td bgcolor='white'>" + (i + j) + "</td>");
        }
        else if (i % 2 && j % 2 || i % 2 == 0 && j % 2 == 0 && i !== 0 && j != 0) {
            document.writeln("<td bgcolor='red'>" + i * j + "</td>");
        } else {
            document.writeln("<td bgcolor='yellow'>" + i * j + "</td>");
        }
    }
    document.writeln("</tr>");
}
document.writeln("</table>");


