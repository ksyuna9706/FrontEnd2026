let n = +prompt("Введите число символов");
let type = prompt("Введите тип символов");
let or = +prompt("0 - горизонтальная, 1 - вертикальная.Введите ориентацию линии: ");
for (let i = 1; i <= n; i++) {
    if (or == 0) {
        type;
        document.writeln(type);
    } else {
        document.writeln(type + "<br>");
    }
} 
