//Задача 1//

// let start =10;
// let end = 30;
// let pr=1;
// while(start <=end){
//     if(start%2){
//     document.writeln( "Число " + start + "<br>");
//     pr*=start;}
//     start++;
// }
//  document.writeln( "Произведение = " + pr + "<br>");

//Задача 2//

let n;
let count =0;
let sum=0;
do {
    n = +prompt("Введите целое число");
    document.writeln(n + "<br>");
    if (n != 0) {
        count++;
        sum=sum+n;
    }

} while (n != 0);
document.writeln("Количество: " + count + "<br>");
document.writeln("Сумма: " + sum + "<br>");
document.writeln("Среднее арифметическое: " + (sum/count) + "<br>");