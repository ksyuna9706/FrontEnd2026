
let a = document.querySelectorAll(".pane");
let b = document.querySelectorAll(".remove-button");
for (let i = 0; i < 3; i++) {
        b[i].addEventListener("click", on);
        function on(){
                a[i].remove();
        }    
};

